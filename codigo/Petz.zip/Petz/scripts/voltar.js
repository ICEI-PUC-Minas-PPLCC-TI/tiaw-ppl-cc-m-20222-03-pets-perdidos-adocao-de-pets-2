function ftw(){
  window.location.href = "index.html"
}